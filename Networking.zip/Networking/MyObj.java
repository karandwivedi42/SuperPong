public class MyObj{
	public boolean myParam;
}
