public class Pair{
	public String param1;
	public String param2;
}